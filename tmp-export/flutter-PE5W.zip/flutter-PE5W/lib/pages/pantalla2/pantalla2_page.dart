import 'package:flutter/material.dart';

class Pantalla2Page extends StatelessWidget {
  const Pantalla2Page({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFFff0000),
        title: const Text(''),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          Positioned(
      top: 50,
      left: 0,
      child: Text(
      'Nombre',
      textAlign: TextAlign.left,
      style: TextStyle(
        fontSize: 16,
        color: Color(0xFF000000),
      ),
    ),
    ),
          Positioned(
      top: 88,
      left: 44,
      child: SizedBox(
      width: 200,
      height: 56,
      child: TextField(
        style: TextStyle(
          fontSize: 16,
          color: Color(0xFF212121),
        ),
        decoration: InputDecoration(
          hintText: 'Ingresa tu nombre',
          hintStyle: TextStyle(
            color: Color(0xFF9e9e9e),
            fontSize: 16,
          ),
          fillColor: Color(0xFFffffff),
          filled: true,
          border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFff0000),
          width: 2,
        ),
      ),
          contentPadding: EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
          
          
        ),
        
        
        
        
        enabled: true,
      ),
    ),
    ),
          Positioned(
      top: 152,
      left: 0,
      child: Text(
      'Correo',
      textAlign: TextAlign.left,
      style: TextStyle(
        fontSize: 16,
        color: Color(0xFF000000),
      ),
    ),
    ),
          Positioned(
      top: 178,
      left: 44,
      child: SizedBox(
      width: 200,
      height: 56,
      child: TextField(
        style: TextStyle(
          fontSize: 16,
          color: Color(0xFF212121),
        ),
        decoration: InputDecoration(
          hintText: 'Ingresa tu correo',
          hintStyle: TextStyle(
            color: Color(0xFF9e9e9e),
            fontSize: 16,
          ),
          fillColor: Color(0xFFffffff),
          filled: true,
          border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFff0000),
          width: 2,
        ),
      ),
          contentPadding: EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
          
          
        ),
        
        
        keyboardType: TextInputType.emailAddress,
        
        enabled: true,
      ),
    ),
    ),
          Positioned(
      top: 252,
      left: 0,
      child: Text(
      'Contraseña',
      textAlign: TextAlign.left,
      style: TextStyle(
        fontSize: 16,
        color: Color(0xFF000000),
      ),
    ),
    ),
          Positioned(
      top: 278,
      left: 44,
      child: SizedBox(
      width: 200,
      height: 56,
      child: TextField(
        style: TextStyle(
          fontSize: 16,
          color: Color(0xFF212121),
        ),
        decoration: InputDecoration(
          hintText: 'Ingresa tu contraseña',
          hintStyle: TextStyle(
            color: Color(0xFF9e9e9e),
            fontSize: 16,
          ),
          fillColor: Color(0xFFffffff),
          filled: true,
          border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFff0000),
          width: 2,
        ),
      ),
          contentPadding: EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
          
          
        ),
        obscureText: true,
        
        
        
        enabled: true,
      ),
    ),
    ),
          
Positioned(
  top: 415,
  left: 35,
  right: 30,
  child: Table(
    border: TableBorder.all(
      color: Color(0xFFcccccc),
      width: 1.0,
    ),
    columnWidths: { 0: FlexColumnWidth(1), 1: FlexColumnWidth(1), 2: FlexColumnWidth(1) },
    defaultVerticalAlignment: TableCellVerticalAlignment.middle,
    children: [
      
          TableRow(
            decoration: BoxDecoration(color: Color(0xFF800080)),
            children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Encabezado 1",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF000000),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Reguistro",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF000000),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Nombre",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFFffffff),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            )]
          ),

          TableRow(
            decoration: BoxDecoration(color: Color(0xFFf9f9f9)),
            children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 1.1",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 1.2",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 1.3",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            )]
          ),

          TableRow(
            decoration: BoxDecoration(color: null),
            children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 2.1",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 2.2",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 2.3",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            )]
          )
    ],
  ),
)
        ],
      ),
    );
  }
}