import 'package:flutter/material.dart';

class Pantalla1Page extends StatefulWidget {
  const Pantalla1Page({super.key});

  @override
  State<Pantalla1Page> createState() => _Pantalla1PageState();
}

class _Pantalla1PageState extends State<Pantalla1Page> {
  final Map<String, String> _dropdownValues = {};
  final Map<String, bool> _checkboxValues = {};
  @override
  void initState() {
    super.initState();
    _checkboxValues['a065e5f0-6c23-4ab9-8ff7-4d5b4995fab6'] = true;
    _dropdownValues['5b03096d-b56a-4c1d-9bd8-ee2f229d9ffa'] = 'Opción 1';
    _checkboxValues['7c0e79d7-6823-4102-9152-5c8e33e44112'] = true;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Color(0xFF004080),
        title: const Text(''),
        centerTitle: true,
      ),
      body: Stack(
        children: [
          Positioned(
      top: 552,
      left: 59,
      child: Transform.scale(
      scale: 2,
      child: Checkbox(
        value: _checkboxValues['a065e5f0-6c23-4ab9-8ff7-4d5b4995fab6'] ?? true,
        activeColor: Color(0xFFFFFF00),
        checkColor: Color(0xFFff0080),
        side: BorderSide(
          color: Color(0xFF000040),
          width: 3,
        ),
        shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Color(0xFF000040),
          width: 3,
        ),
      ),
        onChanged: (bool? value) {
          setState(() {
            _checkboxValues['a065e5f0-6c23-4ab9-8ff7-4d5b4995fab6'] = value ?? false;
          });
        },
      ),
    ),
    ),
          Positioned(
      top: 623,
      left: 39,
      child: SizedBox(
      width: 120,
      height: 48,
      child: TextButton(
        style: TextButton.styleFrom(
          padding: EdgeInsets.all(4),
          backgroundColor: Color(0xFFffffff),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: BorderSide(color: Color(0xFF000000), width: 2),
          ),
        ),
        onPressed: () => Navigator.pushNamed(context, '/pantalla2'),
        child: Text(
          'Botón',
          style: TextStyle(
            fontSize: 16,
            color: Color(0xFF000000),
          ),
        ),
      ),
    ),
    ),
          Positioned(
      top: 148,
      left: 45,
      child: Container(
      width: 100,
      height: 100,
      decoration: BoxDecoration(
      color: Color(0xFFb03636),
      border: Border.all(
        color: Color(0xFF000000),
        width: 9,
      ),
      borderRadius: BorderRadius.circular(12),
    ),
      
      
    ),
    ),
          Positioned(
      top: 494,
      left: 116,
      child: Text(
      'Si',
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 22,
        color: Color(0xFF000000),
        fontFamily: 'Times New Roman',
      ),
    ),
    ),
          Positioned(
      top: 622,
      left: 198,
      child: SizedBox(
      width: 120,
      height: 48,
      child: TextButton(
        style: TextButton.styleFrom(
          padding: EdgeInsets.all(4),
          backgroundColor: Color(0xFFffffff),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(8),
            side: BorderSide(color: Color(0xFF000000), width: 2),
          ),
        ),
        onPressed: () => Navigator.pushNamed(context, '/pantalla2'),
        child: Text(
          'Botón 2',
          style: TextStyle(
            fontSize: 16,
            color: Color(0xFF000000),
          ),
        ),
      ),
    ),
    ),
          Positioned(
      top: 73,
      left: 61,
      child: SizedBox(
      width: 200,
      height: 56,
      child: TextField(
        style: TextStyle(
          fontSize: 16,
          color: Color(0xFF212121),
        ),
        decoration: InputDecoration(
          hintText: 'Ingresa el texto aquí',
          hintStyle: TextStyle(
            color: Color(0xFF9e9e9e),
            fontSize: 16,
          ),
          fillColor: Color(0xFFffffff),
          filled: true,
          border: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          enabledBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFFe0e0e0),
          width: 1,
        ),
      ),
          focusedBorder: OutlineInputBorder(
        borderRadius: BorderRadius.circular(4),
        borderSide: BorderSide(
          color: Color(0xFF2196f3),
          width: 2,
        ),
      ),
          contentPadding: EdgeInsets.symmetric(
            horizontal: 12,
            vertical: 12,
          ),
          
          
        ),
        
        
        
        
        enabled: true,
      ),
    ),
    ),
          Positioned(
      top: 133,
      left: 171,
      child: Container(
      width: 120,
      height: 40,
      decoration: BoxDecoration(
      color: Color(0xFFffffff),
      border: Border.all(
        color: Color(0xFF000000),
        width: 1,
      ),
      borderRadius: BorderRadius.circular(4),
    ),
      
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _dropdownValues['5b03096d-b56a-4c1d-9bd8-ee2f229d9ffa'],
          isExpanded: true,
          items: <String>['Opción 1', 'Opción 2', 'opcion 3'].map((String value) {
            return DropdownMenuItem<String>(
              value: value,
              child: Padding(
                padding: EdgeInsets.symmetric(horizontal: 8),
                child: Text(
                  value,
                  style: TextStyle(fontSize: 14),
                ),
              ),
            );
          }).toList(),
          onChanged: (String? newValue) {
            setState(() {
              _dropdownValues['5b03096d-b56a-4c1d-9bd8-ee2f229d9ffa'] = newValue ?? '';
            });
          },
        ),
      ),
    ),
    ),
          
Positioned(
  top: 306,
  left: 41,
  right: 30,
  child: Table(
    border: TableBorder.all(
      color: Color(0xFF0000a0),
      width: 4.0,
    ),
    columnWidths: { 0: FlexColumnWidth(1), 1: FlexColumnWidth(1), 2: FlexColumnWidth(1) },
    defaultVerticalAlignment: TableCellVerticalAlignment.middle,
    children: [
      
          TableRow(
            decoration: BoxDecoration(color: Color(0xFFff80ff)),
            children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Encabezado 1",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF000000),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Encabezado 2",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF000000),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Encabezado 3",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF000000),
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
            )]
          ),

          TableRow(
            decoration: BoxDecoration(color: Color(0xFF408080)),
            children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 1.1",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 1.2",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 1.3",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            )]
          ),

          TableRow(
            decoration: BoxDecoration(color: null),
            children: [
            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 2.1",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 2.2",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            ),

            Padding(
              padding: EdgeInsets.all(8.0),
              child: Text(
                "Celda 2.3",
                textAlign: TextAlign.center,
                style: TextStyle(
                  color: Color(0xFF333333),
                  fontSize: 12,
                  fontWeight: FontWeight.normal,
                ),
              ),
            )]
          )
    ],
  ),
),
          Positioned(
      top: 486.1166687011719,
      left: 57.2166748046875,
      child: Transform.scale(
      scale: 2,
      child: Checkbox(
        value: _checkboxValues['7c0e79d7-6823-4102-9152-5c8e33e44112'] ?? true,
        activeColor: Color(0xFFFFFF00),
        checkColor: Color(0xFFff0080),
        side: BorderSide(
          color: Color(0xFF000040),
          width: 3,
        ),
        shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(12),
        side: BorderSide(
          color: Color(0xFF000040),
          width: 3,
        ),
      ),
        onChanged: (bool? value) {
          setState(() {
            _checkboxValues['7c0e79d7-6823-4102-9152-5c8e33e44112'] = value ?? false;
          });
        },
      ),
    ),
    ),
          Positioned(
      top: 565.1166687011719,
      left: 114.2166748046875,
      child: Text(
      'No',
      textAlign: TextAlign.center,
      style: TextStyle(
        fontSize: 17,
        color: Color(0xFFed27a8),
        fontFamily: 'Times New Roman',
      ),
    ),
    )
        ],
      ),
    );
  }
}